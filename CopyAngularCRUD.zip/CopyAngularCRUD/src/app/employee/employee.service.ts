import { Injectable } from "@angular/core";
import{HttpClient, HttpHeaders} from "@angular/common/http"
import * as api from "../apiUrls";
import { Observable } from "rxjs";
import { Employee } from "./employeeModel";
@Injectable({
    providedIn:'root'
})
export class EmployeeSerivce{

    constructor(private http:HttpClient){

    }
    getAllEmployees():Observable<Employee[]>{
        return this.http.get<Employee[]>(api.getAllEmployees);
    }

    getEmpById(id:number):Observable<Employee>{
        return this.http.get<Employee>(api.getEmpById+id);
    }

    postAddEmployee(emp:any):Observable<any>{
        const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
            })
          };
          httpOptions.headers = httpOptions.headers.set('Authorization', '');
       return this.http.post<any>(api.postAddEmployees,emp,httpOptions);
    }

    updateEmployee(emp:any):Observable<any>{
        const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
            })
          };
          httpOptions.headers = httpOptions.headers.set('Authorization', '');
       return this.http.post<any>(api.updateEmployees,emp,httpOptions);
    }
    
    deleteEmployeeById(id:number):Observable<any>{
      return this.http.get<any>(api.deleteEmployeeById+id);
    }
}