import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeSerivce } from './employee.service';
import { Employee } from './employeeModel';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  isUpdate:boolean=false;
  empList:Employee[]=[];
  empForm=this.fb.group({
    id:[''],
    name:[''],
    gender:[''],
    dob:[''],
    city:['']
  });
  constructor(private empSerive:EmployeeSerivce,private fb:FormBuilder) { }

  ngOnInit(): void {
    this.getAllEmployees();
   
  }

  
  getAllEmployees(){
    this.empSerive.getAllEmployees().subscribe(res=>{
      if(!!res)
      {
        this.empList=res;
        console.log(this.empList);
      }
    })
  }
  saveData(){
    //console.log(this.empForm.value);
    const emp=this.empForm.value;
    if(!this.isUpdate){
      emp.id=null;
      this.empSerive.postAddEmployee(emp).subscribe(res=>{
          console.log(res);
            this.getAllEmployees();
            this.empForm.reset();
        });
    }
    else if(this.isUpdate){
      this.empSerive.updateEmployee(emp).subscribe(res=>{
        console.log(res);
          this.getAllEmployees();
          this.empForm.reset();
      });
    }
  }
  changeGender(val:any){
    this.empForm.value.gender=val.target.value;
    //console.log(val.target.value);
  }
  Edit(id:number){
    this.isUpdate=true;
    this.empSerive.getEmpById(id).subscribe(res=>{
     // console.log(res)
     this.empForm.controls["city"].setValue(res.city);
     this.empForm.controls["id"].setValue(res.id.toString());
     this.empForm.controls["dob"].setValue(res.dob);
     this.empForm.controls["name"].setValue(res.name);
     this.empForm.controls["gender"].setValue(res.gender);
    });
  }

  Delete(id:number){
    
    const res=confirm("Do you wan to delete id "+id.toString() +" ?");
    if(res==true)
    {
      this.empSerive.deleteEmployeeById(id).subscribe(response=>{
        this.getAllEmployees();
      })
    }
  }


  // private formatDate(date:any) {
  //   const d = new Date(date);
  //   let month = '' + (d.getMonth() + 1);
  //   let day = '' + d.getDate();
  //   const year = d.getFullYear();
  //   if (month.length < 2) month = '0' + month;
  //   if (day.length < 2) day = '0' + day;
  //   return [year, month, day].join('-');
  // }
}
