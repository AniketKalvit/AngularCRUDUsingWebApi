export class Employee{
   public id:number=0;
   public name:string="";
   public gender:string="";
   public dob:string="";
   public city:string="";
   
}