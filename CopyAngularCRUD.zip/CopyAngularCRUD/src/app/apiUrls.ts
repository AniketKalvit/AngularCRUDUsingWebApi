"use-strict"
export const baseUrl:string="http://localhost:49221/api/Employee/";

export const getAllEmployees:string=baseUrl+"GetAllEmployees";
export const postAddEmployees:string=baseUrl+"AddEmployee";
export const updateEmployees:string=baseUrl+"UpdateEmployee";
export const getEmpById:string=baseUrl+"GetEmployeeById/";
export const deleteEmployeeById=baseUrl+"DeleteEmployee/";